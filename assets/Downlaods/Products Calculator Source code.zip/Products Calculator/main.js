function calculate(){
    var totalBuy = document.getElementById('total-buy');
    var winByProd = document.getElementById('win-by-product');
    var totalWin = document.getElementById('total-win');
    var buyPrice = document.getElementById('buy-price').value;
    var sellPrice = document.getElementById('sell-price').value;
    var quantity = document.getElementById('quantity').value;
    var main = document.getElementById('main');

    totalBuy.innerHTML= buyPrice * quantity + 'DHs';
    winByProd.innerHTML = (sellPrice - buyPrice) + 'DHs';
    totalWin.innerHTML = (sellPrice - buyPrice) * quantity + 'Dhs';
    main.classList.toggle("showl");
}

function translatingAr(){
    document.getElementById('hi1').innerHTML= `<p class='arabic'> : ثمن البيع</p>`;
    document.getElementById('hi2').innerHTML= `<p class='arabic'> : ثمن الشراء بالجملة</p>`;
    document.getElementById('hi3').innerHTML= `<p class='arabic'> : الكمية</p>`;
    document.getElementById('hi4').innerHTML= `<p class='arabic'> : الربح على المنتوج </p>`;
    document.getElementById('hi5').innerHTML= `<p class='arabic'> : مجموع الربح </p>`;
    document.getElementById('hi6').innerHTML= `<p class='arabic'> : مجموع الإنفاق  </p>`;
    document.getElementById('calculate-btn').innerHTML= `<p class='arabic'>حساب</p>`;
}
function translatingEn(){
    document.getElementById('hi1').innerHTML= 'Product sell price';
    document.getElementById('hi2').innerHTML= 'Product buy price';
    document.getElementById('hi3').innerHTML= 'Product quantity';
    document.getElementById('hi4').innerHTML= 'Win By Product :';
    document.getElementById('hi5').innerHTML= 'Total win : ';
    document.getElementById('hi6').innerHTML= 'Total to buy : ';
}
function translatingFr(){
    document.getElementById('hi1').innerHTML= 'Prix du vente';
    document.getElementById('hi2').innerHTML= "Prix d'achat";
    document.getElementById('hi3').innerHTML= 'Quantité';
    document.getElementById('hi4').innerHTML= "Gain d'un produit :";
    document.getElementById('hi5').innerHTML= 'Gain total : ';
    document.getElementById('hi6').innerHTML= 'Total à payer : ';
}